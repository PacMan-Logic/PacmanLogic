import random

SEED = 42


def set_seed():
    random.seed(SEED)
